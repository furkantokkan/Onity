param(
    [Parameter(Mandatory = $true)][string]$EvidenceRoot,
    [switch]$Extra
)
$ErrorActionPreference = 'Stop'
$EvidenceRoot = [IO.Path]::GetFullPath($EvidenceRoot)

function Get-UnityCpuSnapshot
{
    $observations = @()
    foreach ($process in @(Get-Process -Name Unity -ErrorAction SilentlyContinue))
    {
        try
        {
            $observations += [pscustomobject]@{
                pid = $process.Id
                startUtc = $process.StartTime.ToUniversalTime().ToString('O')
                cpuSeconds = $process.TotalProcessorTime.TotalSeconds
                observed = $true
            }
        }
        catch
        {
            $observations += [pscustomobject]@{ pid = $process.Id; observed = $false }
        }
    }
    return $observations
}

function Get-NoiseObservation($Before, $After, [double]$WallSeconds)
{
    $unknown = $false
    $cpu = 0.0
    foreach ($item in $Before)
    {
        $matched = @($After | Where-Object { $_.pid -eq $item.pid -and $_.startUtc -eq $item.startUtc })
        if (!$item.observed -or $matched.Count -ne 1 -or !$matched[0].observed)
        {
            $unknown = $true
        }
        else
        {
            $delta = $matched[0].cpuSeconds - $item.cpuSeconds
            if ($delta -lt 0)
            {
                $unknown = $true
            }
            else
            {
                $cpu += $delta
            }
        }
    }
    foreach ($item in $After)
    {
        if (@($Before | Where-Object { $_.pid -eq $item.pid -and $_.startUtc -eq $item.startUtc }).Count -ne 1)
        {
            $unknown = $true
        }
    }
    $fraction = if ($WallSeconds -gt 0) { $cpu / $WallSeconds } else { [double]::PositiveInfinity }
    $status = if ($unknown) { 'unknown' } elseif ($cpu -le 0.5 -and $fraction -le 0.05) { 'accepted' } else { 'flagged' }
    return [pscustomobject]@{ unknown = $unknown; cpu = $cpu; fraction = $fraction; status = $status }
}

function Add-Pair([string]$Backend, [int]$Round, [bool]$CandidateFirst)
{
    $revisions = if ($CandidateFirst) { @('candidate', 'baseline') } else { @('baseline', 'candidate') }
    foreach ($revision in $revisions)
    {
        $script:runs += [pscustomobject]@{ backend = $Backend; round = $Round; revision = $revision }
    }
}

$runs = @()
$quietHash = $null
if (!$Extra)
{
    # Three fixed rounds, with backend and revision orders reversed/interleaved before observing results.
    Add-Pair 'Mono' 1 $false
    Add-Pair 'IL2CPP' 1 $true
    Add-Pair 'IL2CPP' 2 $false
    Add-Pair 'Mono' 2 $true
    Add-Pair 'Mono' 3 $false
    Add-Pair 'IL2CPP' 3 $true
}
else
{
    $quietPath = Join-Path $EvidenceRoot 'quiet-recheck.json'
    if (!(Test-Path -LiteralPath $quietPath))
    {
        throw 'Replacement round requires quiet-recheck.json.'
    }
    $quiet = Get-Content -LiteralPath $quietPath -Raw | ConvertFrom-Json
    if ($quiet.unknown -ne $false -or $null -eq $quiet.otherUnityCpuSeconds -or
        $null -eq $quiet.otherUnityWallFraction -or $quiet.otherUnityCpuSeconds -lt 0 -or
        $quiet.otherUnityWallFraction -lt 0 -or $quiet.otherUnityCpuSeconds -gt 0.5 -or
        $quiet.otherUnityWallFraction -gt 0.05)
    {
        throw 'Replacement round requires known quiet activity <=0.5 CPU seconds AND <=5% wall.'
    }
    $quietHash = (Get-FileHash -LiteralPath $quietPath -Algorithm SHA256).Hash
    if (!$quiet.startedUtc -or !$quiet.elapsedSeconds -or $quiet.elapsedSeconds -le 0)
    {
        throw 'Replacement round requires a dated quiet recheck with positive elapsed time.'
    }
    $quietStarted = [DateTime]::Parse($quiet.startedUtc).ToUniversalTime()
    foreach ($backend in @('IL2CPP', 'Mono'))
    {
        $flaggedPair = $false
        $acceptedPairs = 0
        for ($round = 1; $round -le 3; $round++)
        {
            $pairAccepted = $true
            foreach ($revision in @('baseline', 'candidate'))
            {
                $stem = $revision + '-' + $backend.ToLowerInvariant() + '-r' + $round
                $observation = Get-Content -LiteralPath (Join-Path $EvidenceRoot ($stem + '.observation.json')) -Raw | ConvertFrom-Json
                if ($quietStarted -le [DateTime]::Parse($observation.endedUtc).ToUniversalTime())
                {
                    throw 'Quiet recheck must occur after all initial rounds.'
                }
                if ($observation.noiseStatus -eq 'flagged')
                {
                    $flaggedPair = $true
                }
                $pairAccepted = $pairAccepted -and $observation.noiseStatus -eq 'accepted'
            }
            if ($pairAccepted)
            {
                $acceptedPairs++
            }
        }
        if ($flaggedPair -and $acceptedPairs -lt 3)
        {
            Add-Pair $backend 4 $true
        }
    }
    if ($runs.Count -eq 0)
    {
        throw 'No backend has a flagged initial pair eligible for the single replacement round.'
    }
}

# Refuse the entire dispatch before launching anything if any planned evidence would be overwritten.
foreach ($run in $runs)
{
    $stem = $run.revision + '-' + $run.backend.ToLowerInvariant() + '-r' + $run.round
    $binary = Join-Path $EvidenceRoot ('Players/' + $run.revision + '-' + $run.backend + '/OnityTaskBenchmark.exe')
    if (!(Test-Path -LiteralPath $binary) -or !(Test-Path -LiteralPath ($binary + '.build.json')))
    {
        throw 'Missing exact executable or build sidecar: ' + $binary
    }
    foreach ($suffix in @('.json', '.startup.log', '.player.log', '.observation.json'))
    {
        if (Test-Path -LiteralPath (Join-Path $EvidenceRoot ($stem + $suffix)))
        {
            throw 'Refusing existing evidence: ' + $stem + $suffix
        }
    }
}

$failedRuns = @()
$sequence = 0
foreach ($run in $runs)
{
    $sequence++
    $stem = $run.revision + '-' + $run.backend.ToLowerInvariant() + '-r' + $run.round
    $binary = Join-Path $EvidenceRoot ('Players/' + $run.revision + '-' + $run.backend + '/OnityTaskBenchmark.exe')
    $report = Join-Path $EvidenceRoot ($stem + '.json')
    $startup = Join-Path $EvidenceRoot ($stem + '.startup.log')
    $log = Join-Path $EvidenceRoot ($stem + '.player.log')
    $binaryHash = (Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash
    $sidecarHash = (Get-FileHash -LiteralPath ($binary + '.build.json') -Algorithm SHA256).Hash
    $before = @(Get-UnityCpuSnapshot)
    $started = [DateTime]::UtcNow
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $arguments = @(
        '-batchmode', '-nographics', '-onityRunTaskBenchmark',
        '-onityTaskBenchmarkSuite', 'builderlifecycle',
        '-onityTaskBenchmarkOutput', ('"' + $report + '"'),
        '-onityTaskBenchmarkStartupTrace', ('"' + $startup + '"'),
        '-onityTaskBenchmarkBuildMetadata', ('"' + $binary + '.build.json"'),
        '-logFile', ('"' + $log + '"')
    )
    $player = Start-Process -FilePath $binary -ArgumentList $arguments -WindowStyle Hidden -PassThru
    $timedOut = !$player.WaitForExit(900000)
    if ($timedOut)
    {
        $player.Kill()
        $player.WaitForExit()
    }
    $watch.Stop()
    $ended = [DateTime]::UtcNow
    $after = @(Get-UnityCpuSnapshot)
    $noise = Get-NoiseObservation $before $after $watch.Elapsed.TotalSeconds
    $binaryStable = $binaryHash -eq (Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash
    $sidecarStable = $sidecarHash -eq (Get-FileHash -LiteralPath ($binary + '.build.json') -Algorithm SHA256).Hash
    $identity = [pscustomobject]@{
        schemaVersion = 1
        suite = 'builderlifecycle'
        revision = $run.revision
        backend = $run.backend
        round = $run.round
        sequence = $sequence
        replacement = [bool]$Extra
        quietRecheckSha256 = $quietHash
        executable = $binary
        buildMetadata = $binary + '.build.json'
        report = $report
        startupTrace = $startup
        playerLog = $log
        playerPid = $player.Id
        startedUtc = $started.ToString('O')
        endedUtc = $ended.ToString('O')
        elapsedSeconds = $watch.Elapsed.TotalSeconds
        exitCode = $player.ExitCode
        timedOut = $timedOut
        binarySha256 = $binaryHash
        buildMetadataSha256 = $sidecarHash
        binaryStable = $binaryStable
        buildMetadataStable = $sidecarStable
        reportSha256 = if (Test-Path -LiteralPath $report) { (Get-FileHash -LiteralPath $report -Algorithm SHA256).Hash } else { $null }
        startupSha256 = if (Test-Path -LiteralPath $startup) { (Get-FileHash -LiteralPath $startup -Algorithm SHA256).Hash } else { $null }
        playerLogSha256 = if (Test-Path -LiteralPath $log) { (Get-FileHash -LiteralPath $log -Algorithm SHA256).Hash } else { $null }
        otherUnityBefore = $before
        otherUnityAfter = $after
        unknown = $noise.unknown
        otherUnityCpuSeconds = $noise.cpu
        otherUnityWallFraction = $noise.fraction
        noiseStatus = $noise.status
        noiseRule = 'Other Unity CPU <=0.5s AND <=5% wall; no core normalization. Missing/new/unreadable process is unknown.'
        taskOwnedOverlap = 'Root must run only after all task-owned builds, tests and Roslyn finish; helper launches Players sequentially.'
        orderPolicy = 'Fixed rounds: r1 Mono baseline/candidate, IL2CPP candidate/baseline; r2 IL2CPP baseline/candidate, Mono candidate/baseline; r3 same as r1.'
    }
    $identity | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $EvidenceRoot ($stem + '.observation.json')) -Encoding UTF8
    Write-Output ($stem + ' exit=' + $player.ExitCode + ' wall=' + $watch.Elapsed.TotalSeconds.ToString('F3') +
        's UnityCPU=' + $noise.cpu.ToString('F3') + 's noise=' + $noise.status)
    if ($timedOut -or $player.ExitCode -ne 0 -or !(Test-Path -LiteralPath $report) -or !$binaryStable -or !$sidecarStable)
    {
        $failedRuns += $stem
    }
}
if ($failedRuns.Count -ne 0)
{
    throw 'Fixed collection completed with failed processes retained: ' + ($failedRuns -join ', ')
}
