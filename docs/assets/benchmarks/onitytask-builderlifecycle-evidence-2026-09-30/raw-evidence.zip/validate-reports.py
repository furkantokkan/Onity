"""Validate fixed builder-lifecycle evidence without launching Players or selecting favorable results."""
import argparse
from datetime import datetime
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import statistics
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def close(actual, expected, label):
    require(isinstance(actual, (int, float)) and math.isfinite(actual), label + ": nonfinite/missing value")
    require(math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-7), label + ": arithmetic mismatch")


def integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, label + ": invalid integer")
    return value


def validate_environment(env, backend, flow, build_guid=None):
    require(env["scriptingBackend"] == backend, "backend mismatch")
    require(env["isDevelopment"] is False, "development build")
    require(env.get("isEditor", False) is False, "Editor report")
    require(env["flowExecutionContext"] is flow, "environment flow mismatch")
    require(env["runnerPoolCapacity"] == 128, "capacity changed")
    require(env["trackerEnabled"] is False and env["trackerStackTraceEnabled"] is False, "tracker enabled")
    require(env["executionContextPath"] in ("InternalPair", "PublicFallback"), "unknown context path")
    require(bool(env["executionContextEvidence"]), "missing context evidence")
    require(bool(env["buildGuid"]), "missing build GUID")
    if build_guid is not None:
        require(env["buildGuid"] == build_guid, "metric build GUID mismatch")
    build = env["build"]
    require("Release" in build["codeOptimization"] and "BuildOptions.None" in build["codeOptimization"], "not Release")
    require(build["il2CppCompilerConfiguration"] == "Release", "IL2CPP configuration changed")
    require(build["uniTaskVersion"] == "2.5.11", "pinned UniTask version changed")
    require("2e993ff18f28c931602a07292df0b0804eebef99" in build["uniTaskPackageId"], "UniTask pin changed")


def validate_startup(path):
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    rows = [re.split(r"\t|\\t", line) for line in lines if line.strip()]
    stages = [row[1] for row in rows if len(row) >= 2]
    expected = ["early-initialization", "before-scene-load", "after-scene-load", "arguments-detected",
                "benchmark-entry", "benchmark-completed"]
    require(stages == expected, "startup stages missing/out of order/failed")
    require(rows[4][2] == "builderlifecycle", "startup suite mismatch")


def validate_control(control, steps, brackets, checksum):
    require(len(control["completionTicks"]) == steps, "control completion shape")
    ticks = [control["scheduleTicks"], *control["completionTicks"], control["consumptionTicks"],
             control["drainFirstTicks"], control["drainSecondTicks"]]
    for tick in ticks:
        integer(tick, "control ticks")
    require(control["totalTicks"] == sum(ticks), "control total mismatch")
    require(control["phaseBracketCount"] == brackets and control["checksum"] == checksum, "control brackets/checksum")


def validate_sample(sample, metric, index, frequency, il2cpp):
    count = metric["cohortSize"]
    steps = metric["sequentialSuspensions"]
    invocations = metric["invocations"]
    operations = count * invocations
    onity = metric["library"] == "OnityTask"
    typed = metric["shape"] == "Typed int"
    brackets = (steps + 4) * invocations
    require(sample["index"] == index and sample["libraryOrder"] == ((index & 1) if onity else 1 - (index & 1)),
            "sample index/library order")
    require(sample["operations"] == operations and sample["phaseBracketCount"] == brackets, "sample work/brackets")
    require(sample["validated"] is True and sample["safetyFrames"] >= 2, "validation/safety frames")
    require(sample["safetyEndFrame"] - sample["safetyStartFrame"] == sample["safetyFrames"], "frame arithmetic")
    require(len(sample["completionTicks"]) == steps and len(sample["completionNanosecondsPerOperation"]) == steps,
            "completion phase shape")
    ticks = [sample["scheduleTicks"], *sample["completionTicks"], sample["consumptionTicks"],
             sample["drainFirstTicks"], sample["drainSecondTicks"]]
    for tick in ticks:
        integer(tick, "phase ticks")
    require(sample["totalTicks"] == sum(ticks), "phase total mismatch")
    factor = 1e9 / frequency / operations
    for field, tick in (("scheduleNanosecondsPerOperation", sample["scheduleTicks"]),
                        ("consumptionNanosecondsPerOperation", sample["consumptionTicks"]),
                        ("drainFirstNanosecondsPerOperation", sample["drainFirstTicks"]),
                        ("drainSecondNanosecondsPerOperation", sample["drainSecondTicks"]),
                        ("totalNanosecondsPerOperation", sample["totalTicks"])):
        close(sample[field], tick * factor, field)
    for actual, tick in zip(sample["completionNanosecondsPerOperation"], sample["completionTicks"]):
        close(actual, tick * factor, "completion ns/op")
    for field in ("registrations", "callbacks", "completions", "gateResults"):
        require(sample[field] == operations * steps, field + " count")
    require(sample["nativeConsumptions"] == operations, "native single consumption count")
    require(sample["resultChecksum"] == operations * (42 if typed else 1), "native result checksum")
    expected_onity = count if il2cpp and onity else 0
    expected_uni = count if il2cpp and not onity else 0
    require(sample["expectedOnityBeforeFirstPassPerInvocation"] == expected_onity, "Onity expected queue count")
    require(sample["expectedUniBeforeFirstPassPerInvocation"] == expected_uni, "UniTask expected queue count")
    require(sample["onityBeforeFirstPassSum"] == expected_onity * invocations, "Onity observed queue sum")
    require(sample["uniBeforeFirstPassSum"] == expected_uni * invocations, "UniTask observed queue sum")
    for field in ("expectedBeforeFirstPassChecks", "zeroBeforeInvocationCount", "zeroBetweenDrainsCount", "zeroAfterDrainsCount"):
        require(sample[field] == invocations, field + " proof count")
    validate_control(sample["timestampControl"], steps, brackets, 0)
    validate_control(sample["arrayLoopControl"], steps, brackets, operations * (1 + steps))


def phase_medians(metric):
    samples = metric["samples"]
    fields = {"schedule": "scheduleNanosecondsPerOperation", "consume": "consumptionNanosecondsPerOperation",
              "returnFirst": "drainFirstNanosecondsPerOperation", "returnSecond": "drainSecondNanosecondsPerOperation",
              "total": "totalNanosecondsPerOperation"}
    result = {name: statistics.median(sample[field] for sample in samples) for name, field in fields.items()}
    for step in range(metric["sequentialSuspensions"]):
        result["completion" + str(step + 1)] = statistics.median(
            sample["completionNanosecondsPerOperation"][step] for sample in samples)
    result["completionSum"] = statistics.median(sum(sample["completionNanosecondsPerOperation"]) for sample in samples)
    result["returnSum"] = statistics.median(sample["drainFirstNanosecondsPerOperation"]
                                            + sample["drainSecondNanosecondsPerOperation"] for sample in samples)
    return result


def validate_report(path, expected_backend=None):
    data = load(path)
    require(data["schemaVersion"] == 1 and data["completed"] is True, "report schema/completion")
    require(not data["failure"] and not data["loggedError"], "report failure/logged error")
    require(data.get("isEditor", False) is False, "Editor report")
    backend = data["environment"]["scriptingBackend"]
    require(backend in ("Mono", "IL2CPP") and (expected_backend is None or backend == expected_backend), "report backend")
    validate_environment(data["environment"], backend, True)
    require(data["isIl2Cpp"] is (backend == "IL2CPP"), "backend compile flag")
    require(data["onityRunnerPoolCapacity"] == 128 and data["uniTaskMaxPoolSize"] == 2147483647, "pool policy")
    require(data["warmupsPerLibrary"] == 2 and data["samplesPerLibrary"] == 8, "sample policy")
    require(data["goldensPassed"] is True and data["multiSuspensionGoldensPassed"] == 8, "fixed goldens")
    require(data["preallocatedGateCapacity"] == 16384 and data["nativeTaskArrayCapacity"] == 4096, "buffer capacity")
    frequency = integer(data["stopwatchFrequency"], "Stopwatch frequency", 1)
    require("ELAPSED" in data["measurementScope"] and "both libraries" in data["measurementScope"], "elapsed scope")
    require("unsubtracted" in data["controls"].lower() and "unsubtracted" in data["returnBoundary"].lower(), "control subtraction")
    require(data["allocation"].startswith("UNAVAILABLE:") and "no zero-allocation" in data["allocation"], "allocation claim")
    require("Onity.Unity.Async.OnityTaskMainThreadDispatcher.Drain" in data["drainBinding"], "Onity binding")
    require("ContinuationQueue.Run" in data["uniDrainBinding"] and "LastPostLateUpdate" in data["uniDrainBinding"], "UniTask binding")
    validate_startup(path.with_suffix(".startup.log"))
    expected = set(itertools.product((True, False), ("Untyped", "Typed int"), (1, 128, 4096), (1, 4), ("OnityTask", "UniTask")))
    actual = set()
    cases = {}
    require(len(data["metrics"]) == 48, "metric count")
    for metric in data["metrics"]:
        key = (metric["onityFlowExecutionContext"], metric["shape"], metric["cohortSize"],
               metric["sequentialSuspensions"], metric["library"])
        require(key in expected and key not in actual, "metric matrix/duplicate")
        actual.add(key)
        flow, shape, count, steps, library = key
        invocations = max(1, 4096 // count)
        require(metric["invocations"] == invocations and metric["operations"] == count * invocations, "fixed invocation policy")
        require(metric["diagnosticOnly"] is (count == 1 or not flow), "diagnostic classification")
        validate_environment(metric["environment"], backend, flow, data["environment"]["buildGuid"])
        for field, length in (("warmups", 2), ("samples", 8)):
            require(len(metric[field]) == length, field + " count")
            for index, sample in enumerate(metric[field]):
                validate_sample(sample, metric, index, frequency, backend == "IL2CPP")
        case_key = f"flow={flow};shape={shape};N={count};steps={steps}"
        case = cases.setdefault(case_key, {"flow": flow, "shape": shape, "N": count, "steps": steps,
                                           "diagnosticOnly": count == 1 or not flow, "rawMedianPhaseNs": {}})
        case["rawMedianPhaseNs"][library] = phase_medians(metric)
    require(actual == expected, "incomplete metric matrix")
    for case in cases.values():
        onity = case["rawMedianPhaseNs"]["OnityTask"]
        uni = case["rawMedianPhaseNs"]["UniTask"]
        case["onityOverUniRatios"] = {phase: onity[phase] / uni[phase] if uni[phase] else None for phase in onity}
    return {"valid": True, "backend": backend, "sha256": sha(path), "metrics": 48, "warmups": 96,
            "measuredSamples": 384, "goldens": 8, "cases": cases,
            "nonEditorEvidence": "Successful known Release Player harness guard; schema has no explicit isEditor field."}


def noise_from_snapshots(before, after, wall):
    require(wall > 0 and math.isfinite(wall), "observation elapsed time")
    unknown = False
    cpu = 0.0
    def known(item):
        return (item.get("observed") is True and type(item.get("pid")) is int and bool(item.get("startUtc"))
                and isinstance(item.get("cpuSeconds"), (int, float)) and math.isfinite(item["cpuSeconds"]))
    for collection in (before, after):
        identities = [(item.get("pid"), item.get("startUtc")) for item in collection]
        require(len(set(identities)) == len(identities), "duplicate Unity process identity")
        for item in collection:
            require(set(item) <= {"pid", "startUtc", "cpuSeconds", "observed"}, "unsanitized Unity snapshot")
    for item in before:
        matched = [other for other in after if other.get("pid") == item.get("pid") and other.get("startUtc") == item.get("startUtc")]
        if not known(item) or len(matched) != 1 or not known(matched[0]):
            unknown = True
        else:
            delta = matched[0]["cpuSeconds"] - item["cpuSeconds"]
            if delta < 0 or not math.isfinite(delta):
                unknown = True
            else:
                cpu += delta
    for item in after:
        if sum(other.get("pid") == item.get("pid") and other.get("startUtc") == item.get("startUtc") for other in before) != 1:
            unknown = True
    fraction = cpu / wall
    status = "unknown" if unknown else "accepted" if cpu <= 0.5 and fraction <= 0.05 else "flagged"
    return unknown, cpu, fraction, status


def replacement_eligible(initial_observations, backend):
    return any(observation["backend"] == backend and observation["noiseStatus"] == "flagged"
               for observation in initial_observations)


def validate_observation(root, path, revision, backend, round_number):
    observation_path = path.with_suffix(".observation.json")
    obs = load(observation_path)
    require(obs["schemaVersion"] == 1 and obs["suite"] == "builderlifecycle", "observation schema/suite")
    require((obs["revision"], obs["backend"], obs["round"]) == (revision, backend, round_number), "observation identity")
    require(obs["replacement"] is (round_number == 4), "replacement flag")
    require(obs["exitCode"] == 0 and obs["timedOut"] is False, "Player failure/timeout")
    require(obs["binaryStable"] is True and obs["buildMetadataStable"] is True, "build changed during process")
    binary = root / "Players" / (revision + "-" + backend) / "OnityTaskBenchmark.exe"
    require(Path(obs["executable"]).resolve() == binary.resolve(), "wrong executable path")
    require(Path(obs["report"]).resolve() == path.resolve(), "wrong report path")
    for artifact, field in ((binary, "binarySha256"), (Path(str(binary) + ".build.json"), "buildMetadataSha256"),
                            (path, "reportSha256"), (path.with_suffix(".startup.log"), "startupSha256"),
                            (path.with_suffix(".player.log"), "playerLogSha256")):
        require(sha(artifact) == obs[field].upper(), field + " changed")
    sidecar = load(Path(str(binary) + ".build.json"))
    report_build = load(path)["environment"]["build"]
    require(sidecar == report_build, "report build metadata differs from sidecar")
    unknown, cpu, fraction, status = noise_from_snapshots(obs["otherUnityBefore"], obs["otherUnityAfter"], obs["elapsedSeconds"])
    require(obs["unknown"] is unknown and obs["noiseStatus"] == status, "noise classification")
    close(obs["otherUnityCpuSeconds"], cpu, "noise CPU")
    close(obs["otherUnityWallFraction"], fraction, "noise wall fraction")
    if round_number == 4:
        quiet_path = root / "quiet-recheck.json"
        quiet = load(quiet_path)
        require(quiet["unknown"] is False and 0 <= quiet["otherUnityCpuSeconds"] <= 0.5
                and 0 <= quiet["otherUnityWallFraction"] <= 0.05, "replacement quiet prerequisite")
        require(sha(quiet_path) == obs["quietRecheckSha256"].upper(), "replacement quiet identity")
        quiet_unknown, quiet_cpu, quiet_fraction, quiet_status = noise_from_snapshots(
            quiet["before"], quiet["after"], quiet["elapsedSeconds"])
        require(not quiet_unknown and quiet_status == "accepted", "replacement quiet snapshots")
        close(quiet["otherUnityCpuSeconds"], quiet_cpu, "quiet CPU")
        close(quiet["otherUnityWallFraction"], quiet_fraction, "quiet wall fraction")
        initial_observations = [load(root / f"{rev}-{be.lower()}-r{r}.observation.json")
                                for be in ("Mono", "IL2CPP") for r in (1, 2, 3) for rev in ("baseline", "candidate")]
        quiet_started = datetime.fromisoformat(quiet["startedUtc"].replace("Z", "+00:00"))
        require(all(quiet_started > datetime.fromisoformat(initial["endedUtc"].replace("Z", "+00:00"))
                    for initial in initial_observations), "quiet recheck predates initial rounds")
        backend_initial_observations = [load(root / f"{rev}-{backend.lower()}-r{r}.observation.json")
                                        for r in (1, 2, 3) for rev in ("baseline", "candidate")]
        require(replacement_eligible(backend_initial_observations, backend), "unjustified replacement round")
    return {"noiseStatus": status, "otherUnityCpuSeconds": cpu, "otherUnityWallFraction": fraction,
            "observationSha256": sha(observation_path), "revision": revision, "round": round_number,
            "sequence": obs["sequence"]}


def compare_pair(baseline, candidate):
    result = {}
    for key, first in baseline["cases"].items():
        second = candidate["cases"][key]
        result[key] = {"baselineOnityOverUni": first["onityOverUniRatios"],
                       "candidateOnityOverUni": second["onityOverUniRatios"],
                       "candidateOverBaselineOnity": {}, "candidateOverBaselineUni": {}}
        for library, target in (("OnityTask", "candidateOverBaselineOnity"), ("UniTask", "candidateOverBaselineUni")):
            for phase, value in first["rawMedianPhaseNs"][library].items():
                result[key][target][phase] = second["rawMedianPhaseNs"][library][phase] / value if value else None
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence-root", type=Path, default=Path(__file__).parent)
    parser.add_argument("--reports", nargs="*", type=Path)
    parser.add_argument("--check-only", action="store_true", help="Validate/read only; do not write generated summary.")
    args = parser.parse_args()
    root = args.evidence_root.resolve()
    paths = args.reports if args.reports is not None else sorted(root.glob("*.json"))
    report_pattern = re.compile(r"^(baseline|candidate)-(mono|il2cpp)-r([1-4])\.json$")
    records = {}
    errors = []
    for supplied in paths:
        path = supplied if supplied.is_absolute() else root / supplied
        matched = report_pattern.match(path.name)
        if args.reports is None and not matched and not path.name.endswith("-build-validation.json"):
            continue
        try:
            backend = ("Mono" if matched[2] == "mono" else "IL2CPP") if matched else None
            record = validate_report(path, backend)
            record["report"] = path.name
            if matched:
                record.update(validate_observation(root, path, matched[1], backend, int(matched[3])))
            else:
                record["noiseStatus"] = "validation-only"
            records[path.name] = record
            print(f"PASS {path.name}: 48 metrics, 96 warmups, 384 measured samples, 8 goldens; {record['noiseStatus']}")
        except (ValueError, KeyError, TypeError, IndexError, OSError, json.JSONDecodeError) as exception:
            records[path.name] = {"valid": False, "report": path.name, "error": str(exception)}
            errors.append(path.name + ": " + str(exception))
            print("FAIL " + errors[-1])
    require(bool(records), "no lifecycle reports selected")
    pairs = {"accepted": [], "flagged": [], "invalidOrMissing": []}
    selections = {}
    for backend in ("Mono", "IL2CPP"):
        eligible = []
        for round_number in (1, 2, 3, 4):
            names = [f"{revision}-{backend.lower()}-r{round_number}.json" for revision in ("baseline", "candidate")]
            entries = [records.get(name) for name in names]
            if round_number == 4 and not any(entry is not None for entry in entries):
                continue
            identity = {"backend": backend, "round": round_number, "reports": names}
            if not all(entry and entry.get("valid") for entry in entries):
                pairs["invalidOrMissing"].append(identity)
                continue
            identity["cases"] = compare_pair(*entries)
            if all(entry["noiseStatus"] == "accepted" for entry in entries):
                pairs["accepted"].append(identity)
                eligible.append(round_number)
            else:
                pairs["flagged"].append(identity)
        selections[backend] = {"selectedRounds": eligible[:3], "status": "SUFFICIENT_PAIR_COUNT" if len(eligible) >= 3 else "INCONCLUSIVE"}
    summary = {"schemaVersion": 1, "suite": "builderlifecycle", "reports": records, "pairs": pairs,
               "selection": selections,
               "reportGroups": {name: [key for key, value in records.items() if value.get("valid") and value.get("noiseStatus") in states]
                                for name, states in (("accepted", ("accepted",)), ("flagged", ("flagged", "unknown")),
                                                     ("validationOnly", ("validation-only",)))},
               "selectionRule": "First three VALID PAIRS ascending round, requiring BOTH revisions accepted by the fixed Unity-noise screen. "
                                "Flagged/unknown/invalid evidence retained; never select favorable timings. Maximum one justified replacement pair per backend.",
               "noiseScope": "Only known competing Unity processes screened; <=0.5 CPU seconds AND <=5% wall, no core normalization. "
                             "Root owns exclusion of task builds/tests/Roslyn. This does not establish an idle workstation.",
               "decision": "No automatic general superiority claim; all phases, default-flow rows, diagnostics and flagged evidence require independent review.",
               "errors": errors}
    if not args.check_only:
        output = root / "generated-summary.json"
        output.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n", encoding="utf-8")
        print("Generated " + str(output))
    return 1 if errors else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, OSError) as exception:
        print("FAIL " + str(exception))
        sys.exit(1)
