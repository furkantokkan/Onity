import hashlib
import json
import math
import pathlib
import statistics
import sys

root = pathlib.Path(sys.argv[1])
arms = ["Managed/OnityTask<int>", "Managed/UniTask<int>", "Burst/OnityTask<int>", "Burst/UniTask<int>"]
rows = []
report_count = 0


def check(path, backend):
    global report_count
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    assert data["completed"] and not data.get("failure") and not data.get("loggedError"), path
    assert data["goldensPassed"] and data["nativeBuffersDisposed"], path
    assert data["environment"]["scriptingBackend"] == backend and not data["environment"]["isDevelopment"]
    assert data["environment"]["flowExecutionContext"] and data["onityRunnerPoolCapacity"] == 128
    assert data["environment"]["build"]["codeOptimization"].startswith("Release (non-development")
    assert data["unityVersion"] == "2022.3.62f2" and data["nativePayloadBytes"] == 311304
    assert data["ticksPerCycle"] == 9 and data["pendingTicksPerCycle"] == 8
    assert data["initialRemainingSeconds"] == 2.25 and data["deltaSeconds"] == 0.25
    assert len(data["goldens"]) == 4 and len(data["metrics"]) == 8
    for arm, golden in enumerate(data["goldens"]):
        assert golden["arm"] == arms[arm]
        assert all(golden[name] for name in ("forwardedEightPendingThenTerminal", "cancellationBeforeDeadline",
                   "postScanGenerationRejection", "callbackReentryGenerationRejection", "reusedGenerationCompletedOnce"))
    for mi, metric in enumerate(data["metrics"]):
        arm = mi % 4
        count = [128, 4096][mi // 4]
        assert metric["arm"] == arms[arm] and metric["count"] == count
        assert len(metric["samples"]) == 8 and len(metric["warmups"]) == 2
        for group in (metric["warmups"], metric["samples"]):
            for si, sample in enumerate(group):
                assert sample["validated"] and sample["index"] == si and sample["order"] == (arm - si) % 4
                assert sample["pendingBefore"] == 0 and sample["pendingAfter"] == 0
                assert sample["pendingBetweenDrains"] == 0
                assert sample["pendingBeforeDrain"] == (count if backend == "IL2CPP" and arm % 2 == 0 else 0)
                assert sample["tickReadyCounts"] == [0] * 8 + [count]
                assert sample["tickProofs"] == ([0x42555253] if arm >= 2 else [0x4D414E47]) * 9
                for key in ("registrations", "callbacks", "completions", "gateResults", "nativeConsumptions", "dispatches"):
                    assert sample[key] == count
                assert sample["resultChecksum"] == count * 42 and sample["dispatchChecksum"] == count * (count + 1) // 2
                phases = [sample[k] for k in ("registrationTicks", "terminalTicks", "consumptionTicks", "drainFirstTicks", "drainSecondTicks")]
                assert len(sample["pendingTicks"]) == 8
                phases += sample["pendingTicks"]
                assert all(t >= 0 for t in phases) and sum(phases) == sample["totalTicks"] > 0
                ns = sample["totalTicks"] * 1e9 / data["stopwatchFrequency"] / count
                assert math.isclose(sample["totalNanosecondsPerConsumer"], ns, rel_tol=1e-6, abs_tol=0.001)
                assert sample["drainFrames"] == sample["drainEndFrame"] - sample["drainStartFrame"] >= 2
                if data["allocationAvailable"]:
                    assert sample["allocationValid"] and sample["managedBytes"] >= 0
                else:
                    assert not sample["allocationValid"] and sample["managedBytes"] == -1
    report_count += 1
    return data


for backend in ("Mono", "IL2CPP"):
    startup = check(root / (backend.lower() + "-build-validation.json"), backend)
    repeats = [1, 2] + ([3] if (root / (backend.lower() + "-r3.json")).exists() else [])
    for repeat in repeats:
        stem = backend.lower() + "-r" + str(repeat)
        path = root / (stem + ".json")
        data = check(path, backend)
        observation = json.loads((root / (stem + ".observation.json")).read_text(encoding="utf-8-sig"))
        assert observation["exitCode"] == 0 and not observation["timedOut"]
        assert observation["reportSha256"].lower() == hashlib.sha256(path.read_bytes()).hexdigest()
        assert data["environment"]["buildGuid"] == startup["environment"]["buildGuid"]
        for size, count in enumerate((128, 4096)):
            medians = [statistics.median(s["totalNanosecondsPerConsumer"] for s in m["samples"]) for m in data["metrics"][size*4:size*4+4]]
            row = {"backend": backend, "repeat": repeat, "noise": observation["noiseStatus"], "count": count,
                   "managedOnityNs": medians[0], "managedUniTaskNs": medians[1], "burstOnityNs": medians[2], "burstUniTaskNs": medians[3],
                   "onityBurstVsManaged": medians[2] / medians[0], "onityVsUniTaskSameBurst": medians[2] / medians[3],
                   "onityVsUniTaskManaged": medians[0] / medians[1], "allocationAvailable": data["allocationAvailable"]}
            rows.append(row)
            print(backend, repeat, count, observation["noiseStatus"], "Onity Burst/managed", round(row["onityBurstVsManaged"], 3),
                  "Onity/UniTask sameBurst", round(row["onityVsUniTaskSameBurst"], 3))
(root / "summary.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
print("PASS:", report_count, "Release reports;", report_count*64, "measured cycles, warmups/goldens, actual drains/proofs checked.")
print("Controlled synchronous phase sums only; no natural PlayerLoop latency or general async claim.")
