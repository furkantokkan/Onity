param(
    [Parameter(Mandatory = $true)][string]$EvidenceRoot,
    [switch]$Extra
)
$ErrorActionPreference = 'Stop'

function Get-UnityCpuSnapshot
{
    $observations = @()
    foreach ($item in @(Get-Process -Name Unity -ErrorAction SilentlyContinue))
    {
        try
        {
            $observations += [pscustomobject]@{
                pid = $item.Id
                startUtc = $item.StartTime.ToUniversalTime().ToString('O')
                cpuSeconds = $item.TotalProcessorTime.TotalSeconds
                observed = $true
            }
        }
        catch
        {
            $observations += [pscustomobject]@{ pid = $item.Id; observed = $false }
        }
    }
    return $observations
}

$runs = @(
    @{ backend = 'Mono'; repeat = 1 },
    @{ backend = 'IL2CPP'; repeat = 1 },
    @{ backend = 'IL2CPP'; repeat = 2 },
    @{ backend = 'Mono'; repeat = 2 }
)
if ($Extra)
{
    $quiet = Get-Content -LiteralPath (Join-Path $EvidenceRoot 'quiet-recheck-final.json') -Raw | ConvertFrom-Json
    if ($quiet.unknown -or $quiet.otherUnityCpuSeconds -gt 0.5 -or $quiet.otherUnityWallFraction -gt 0.05)
    {
        throw 'Competing Unity activity has not changed enough for the permitted extra repeat.'
    }
    $runs = @(@{ backend = 'Mono'; repeat = 3 }, @{ backend = 'IL2CPP'; repeat = 3 })
}
foreach ($run in $runs)
{
    $stem = $run.backend.ToLowerInvariant() + '-r' + $run.repeat
    $binary = Join-Path $EvidenceRoot ('Players/' + $run.backend + '/OnityTaskBenchmark.exe')
    $report = Join-Path $EvidenceRoot ($stem + '.json')
    if (!(Test-Path -LiteralPath $binary) -or (Test-Path -LiteralPath $report))
    {
        throw 'Missing fresh binary or report path already exists: ' + $stem
    }
    $before = @(Get-UnityCpuSnapshot)
    $startedUtc = [DateTime]::UtcNow
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $arguments = @(
        '-batchmode', '-nographics', '-onityRunTaskBenchmark',
        '-onityTaskBenchmarkSuite', 'readiness',
        '-onityTaskBenchmarkOutput', ('"' + $report + '"'),
        '-onityTaskBenchmarkStartupTrace', ('"' + (Join-Path $EvidenceRoot ($stem + '.startup.log')) + '"'),
        '-onityTaskBenchmarkBuildMetadata', ('"' + $binary + '.build.json"'),
        '-logFile', ('"' + (Join-Path $EvidenceRoot ($stem + '.player.log')) + '"')
    )
    $player = Start-Process -FilePath $binary -ArgumentList $arguments -WindowStyle Hidden -PassThru
    $timedOut = !$player.WaitForExit(900000)
    if ($timedOut)
    {
        $player.Kill()
        $player.WaitForExit()
    }
    $watch.Stop()
    $after = @(Get-UnityCpuSnapshot)
    $unknown = $false
    $cpu = 0.0
    foreach ($item in $before)
    {
        $match = @($after | Where-Object { $_.pid -eq $item.pid -and $_.startUtc -eq $item.startUtc })
        if (!$item.observed -or $match.Count -ne 1 -or !$match[0].observed)
        {
            $unknown = $true
        }
        else
        {
            $delta = $match[0].cpuSeconds - $item.cpuSeconds
            if ($delta -lt 0) { $unknown = $true } else { $cpu += $delta }
        }
    }
    foreach ($item in $after)
    {
        if (@($before | Where-Object { $_.pid -eq $item.pid -and $_.startUtc -eq $item.startUtc }).Count -ne 1)
        {
            $unknown = $true
        }
    }
    $fraction = $cpu / $watch.Elapsed.TotalSeconds
    $noise = if ($unknown) { 'unknown' } elseif ($cpu -le 0.5 -and $fraction -le 0.05) { 'accepted' } else { 'flagged' }
    $identity = [pscustomobject]@{
        schemaVersion = 1
        backend = $run.backend
        repeat = $run.repeat
        startedUtc = $startedUtc.ToString('O')
        endedUtc = [DateTime]::UtcNow.ToString('O')
        elapsedSeconds = $watch.Elapsed.TotalSeconds
        exitCode = $player.ExitCode
        timedOut = $timedOut
        binarySha256 = (Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash
        buildMetadataSha256 = (Get-FileHash -LiteralPath ($binary + '.build.json') -Algorithm SHA256).Hash
        reportSha256 = if (Test-Path -LiteralPath $report) { (Get-FileHash -LiteralPath $report -Algorithm SHA256).Hash } else { $null }
        otherUnityBefore = $before
        otherUnityAfter = $after
        otherUnityCpuSeconds = $cpu
        otherUnityWallFraction = $fraction
        noiseStatus = $noise
        noiseRule = 'Other Unity CPU <=0.5s AND <=5% wall, no core normalization; missing/new process is unknown. Only known Unity interference screened.'
        taskOwnedOverlap = 'None: all source/Roslyn/build work finished before process repeats.'
    }
    $identity | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $EvidenceRoot ($stem + '.observation.json')) -Encoding UTF8
    Write-Output ($stem + ' exit=' + $player.ExitCode + ' elapsed=' + $watch.Elapsed.TotalSeconds.ToString('F2') + 's otherUnityCPU=' + $cpu.ToString('F3') + 's noise=' + $noise)
    if ($timedOut -or $player.ExitCode -ne 0 -or !(Test-Path -LiteralPath $report))
    {
        throw 'Readiness Player failed: ' + $stem
    }
}
