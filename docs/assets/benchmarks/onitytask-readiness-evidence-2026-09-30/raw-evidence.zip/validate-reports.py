import json
import math
import pathlib
import statistics
import sys

root = pathlib.Path(sys.argv[1])
proofs = [0x4D414E47, 0x4D414E47, 0x42555253]
rows = []


def check_report(path, backend):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    assert data["schemaVersion"] == 1 and data["completed"] and not data.get("failure"), path
    assert data["boundariesPassed"] and data["generationRejectionPassed"], path
    assert data["generationRejectionVariantsPassed"] == [True, True, True], path
    assert data["environment"]["scriptingBackend"] == backend, path
    assert not data["environment"]["isDevelopment"] and data["environment"]["buildGuid"], path
    assert data["environment"]["flowExecutionContext"] is True, path
    assert data["environment"]["build"]["codeOptimization"].startswith("Release (non-development"), path
    assert data["burstEnabled"] and data["unityVersion"] == "2022.3.62f2", path
    assert (data["caseCount"], data["variants"], data["windows"], data["samplesPerMetric"], data["warmupsPerMetric"]) == (24, 3, 3, 8, 2)
    assert (data["recordBytes"], data["tokenBytes"], data["allocatedNativeBytes"]) == (32, 12, 311304)
    assert len(data["cases"]) == 24 and len(data["boundaries"]) == 9
    for idx, boundary in enumerate(data["boundaries"]):
        assert boundary["validated"] and boundary["proof"] == proofs[idx % 3]
        assert boundary["readyCount"] == 4 and boundary["dispatchCount"] == (0 if idx < 3 else 4)
    for ci, case in enumerate(data["cases"]):
        assert case["index"] == ci and len(case["metrics"]) == 9 and len(case["controls"]) == 8
        count = [1, 32, 128, 4096][ci // 6]
        density = ci % 3
        assert case["count"] == count and case["iterationsPerBatch"] == max(16, min(2048, 32768 // count))
        ready = 0 if density == 0 else (count + 7) // 8 if density == 1 else count
        assert case["expectedReadyCount"] == ready
        for mi, metric in enumerate(case["metrics"]):
            variant = mi % 3
            assert metric["expectedProof"] == proofs[variant]
            assert len(metric["warmups"]) == 2 and len(metric["samples"]) == 8
            for group in (metric["warmups"], metric["samples"]):
                for si, sample in enumerate(group):
                    assert sample["index"] == si and sample["order"] == (variant - si) % 3
                    assert sample["iterations"] == case["iterationsPerBatch"] and sample["batchTicks"] > 0
                    assert sample["validated"] and sample["proof"] == proofs[variant]
                    assert sample["readyCount"] == ready and sample["checksum"] == case["expectedChecksum"]
                    assert sample["dispatchCount"] == (0 if mi < 3 else ready)
                    expected_ns = sample["batchTicks"] * 1e9 / data["stopwatchFrequency"] / sample["iterations"]
                    assert math.isclose(sample["nanosecondsPerInvocation"], expected_ns, rel_tol=1e-6, abs_tol=0.001)
                    assert math.isclose(sample["nanosecondsPerInputElement"], expected_ns / count, rel_tol=1e-6, abs_tol=0.001)
                    if data["allocationAvailable"]:
                        assert sample["allocationValid"] and sample["managedBytes"] >= 0
                    else:
                        assert not sample["allocationValid"] and sample["managedBytes"] == -1
        for control in case["controls"]:
            assert control["validated"] and control["checksum"] == control["iterations"] // 2
    return data


for backend in ("Mono", "IL2CPP"):
    startup = check_report(root / (backend.lower() + "-build-validation.json"), backend)
    for repeat in (1, 2, 3):
        stem = backend.lower() + "-r" + str(repeat)
        data = check_report(root / (stem + ".json"), backend)
        observation = json.loads((root / (stem + ".observation.json")).read_text(encoding="utf-8-sig"))
        assert observation["exitCode"] == 0 and not observation["timedOut"]
        assert data["environment"]["buildGuid"] == startup["environment"]["buildGuid"]
        for case in data["cases"]:
            medians = [statistics.median(s["nanosecondsPerInvocation"] for s in m["samples"]) for m in case["metrics"]]
            rows.append({
                "backend": backend, "repeat": repeat, "noise": observation["noiseStatus"],
                "count": case["count"], "kind": case["kind"], "density": case["density"],
                "managedKernelNs": medians[0], "burstKernelNs": medians[2], "kernelRatio": medians[2] / medians[0],
                "managedCombinedNs": medians[6], "plainCombinedNs": medians[7], "burstCombinedNs": medians[8],
                "combinedRatio": medians[8] / medians[6],
                "allocationAvailable": data["allocationAvailable"],
                "maxManagedBatchBytes": max(s["managedBytes"] for m in case["metrics"] for s in m["samples"]),
            })
    print(backend, "Release: startup+3 repeats validated; native payload 311304 bytes")

(root / "summary.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
for count in (1, 32, 128, 4096):
    for backend in ("Mono", "IL2CPP"):
        selected = [r for r in rows if r["count"] == count and r["backend"] == backend]
        accepted = [r for r in selected if r["noise"] == "accepted"]
        print(backend, count, "combined Burst/C# range", round(min(r["combinedRatio"] for r in selected), 3),
              "..", round(max(r["combinedRatio"] for r in selected), 3), "accepted rows", len(accepted))
print("PASS: 8 complete reports; 13824 measured batch samples plus warmups/goldens checked. Synthetic feasibility only.")
